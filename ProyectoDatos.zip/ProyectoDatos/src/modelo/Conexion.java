
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conexion {
    
    
    
     String dir = "jdbc:sqlite:H://PROYECTO DATOS//";
    String bd = "base1.db";
    String url = dir + bd;
//    String user = "";
//    String contraseña = "";
    Connection conexion = null;



    public Connection getConnention() {
        Connection c;
        System.out.println("Hola");
        if (conexion == null) {

            try {
                conexion = DriverManager.getConnection(url);
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
        return conexion;
    }

    public void desconectar() {
        try {
            conexion.close();
            conexion = null;

            System.out.println("conexión cerrada");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
