/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectoconjuntomvc;

/**
 *
 * @author Diurno
 */
public class ProyectoConjuntoMVC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //https://github.com/vazquez04/proyectoDatos.git
        System.out.println("hola");
        System.out.println("Adios");
    }
    
}
