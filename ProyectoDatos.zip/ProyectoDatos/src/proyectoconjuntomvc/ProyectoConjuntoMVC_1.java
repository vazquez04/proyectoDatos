package proyectoconjuntomvc;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import modelo.Conexion;

public class ProyectoConjuntoMVC_1 {

    public static void main(String[] args) {
        // TODO code application logic here
        //https://github.com/vazquez04/proyectoDatos.git
  
        
       getMostrarTabla("Clientes");
        
    }
    
        public static void getMostrarTabla(String nomTabla) {
            Conexion c = new Conexion();
        StringBuilder datosTabla = new StringBuilder();
        String query = "SELECT * FROM " + nomTabla + ";";

        try (Connection conexion = c.getConnention();     
            PreparedStatement ps = conexion.prepareStatement(query); ResultSet rs = ps.executeQuery()) {

            if (conexion != null) {
                System.out.println("CONEXIÓN EXITOSA");

                
                    while (rs.next()) {
                        String id = Integer.toString(rs.getInt(1));
                        String nombre = rs.getString(2);
                        
                        
                        System.out.println("ID: " + id);
                        System.out.println("NOMBRE: " + nombre);
                    }
               
                }
            else {
                System.out.println("FALLO EN LA CONEXIÓN");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
}