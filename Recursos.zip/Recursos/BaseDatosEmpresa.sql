-- Crear la tabla Clientes
CREATE TABLE Clientes (
    ID_Cliente INTEGER PRIMARY KEY,
    Nombre TEXT,
    Apellido TEXT,
    Direccion TEXT,
    Ciudad TEXT,
    Estado TEXT,
    CodigoPostal TEXT,
    Telefono TEXT,
    CorreoElectronico TEXT
);

-- Crear la tabla Productos
CREATE TABLE Productos (
    ID_Producto INTEGER PRIMARY KEY,
    NombreProducto TEXT,
    Descripcion TEXT,
    PrecioUnitario REAL,
    StockDisponible INTEGER,
    Categoria TEXT,
    Proveedor INTEGER,
    FechaIngreso DATE,
    FOREIGN KEY (Proveedor) REFERENCES Proveedores(ID_Proveedor)
);

-- Crear la tabla Transacciones
CREATE TABLE Transacciones (
    ID_Transaccion INTEGER PRIMARY KEY,
    ID_Cliente INTEGER,
    FechaTransaccion DATE,
    TotalTransaccion REAL,
    MetodoPago TEXT,
    EstadoTransaccion TEXT,
    FOREIGN KEY (ID_Cliente) REFERENCES Clientes(ID_Cliente)
);

-- Crear la tabla DetallesTransacciones
CREATE TABLE DetallesTransacciones (
    ID_Detalle INTEGER PRIMARY KEY,
    ID_Transaccion INTEGER,
    ID_Producto INTEGER,
    CantidadComprada INTEGER,
    PrecioUnitarioEnTransaccion REAL,
    Subtotal REAL,
    FOREIGN KEY (ID_Transaccion) REFERENCES Transacciones(ID_Transaccion),
    FOREIGN KEY (ID_Producto) REFERENCES Productos(ID_Producto)
);

-- Crear la tabla Proveedores
CREATE TABLE Proveedores (
    ID_Proveedor INTEGER PRIMARY KEY,
    NombreProveedor TEXT,
    Direccion TEXT,
    Ciudad TEXT,
    Estado TEXT,
    CodigoPostal TEXT,
    Telefono TEXT,
    CorreoElectronico TEXT
);



-- Insertar datos en la tabla Clientes
INSERT INTO Clientes (Nombre, Apellido, Direccion, Ciudad, Estado, CodigoPostal, Telefono, CorreoElectronico)
VALUES
    ('Juan', 'Perez', 'Calle A, 123', 'Ciudad A', 'Estado A', '12345', '555-1234', 'juan@email.com'),
    ('Maria', 'Gomez', 'Calle B, 456', 'Ciudad B', 'Estado B', '54321', '555-5678', 'maria@email.com'),
    ('Carlos', 'Lopez', 'Calle C, 789', 'Ciudad C', 'Estado C', '67890', '555-9876', 'carlos@email.com'),
    ('Laura', 'Martinez', 'Calle D, 012', 'Ciudad D', 'Estado D', '09876', '555-4321', 'laura@email.com'),
    ('Pedro', 'Gonzalez', 'Calle E, 345', 'Ciudad E', 'Estado E', '23456', '555-8765', 'pedro@email.com');


-- Insertar datos en la tabla Transacciones
INSERT INTO Transacciones (ID_Cliente, FechaTransaccion, TotalTransaccion, MetodoPago, EstadoTransaccion)
VALUES
    (1, '2023-06-01', 59.97, 'Tarjeta', 'Completada'),
    (3, '2023-06-02', 19.98, 'Efectivo', 'Completada'),
    (2, '2023-06-03', 159.95, 'Cheque', 'Pendiente'),
    (4, '2023-06-04', 299.94, 'Transferencia', 'Completada'),
    (5, '2023-06-05', 149.97, 'Tarjeta', 'Completada');

-- Insertar datos en la tabla DetallesTransacciones
INSERT INTO DetallesTransacciones (ID_Transaccion, ID_Producto, CantidadComprada, PrecioUnitarioEnTransaccion, Subtotal)
VALUES
    (1, 1, 3, 19.99, 59.97),
    (2, 3, 2, 9.99, 19.98),
    (3, 2, 5, 29.99, 149.95),
    (4, 4, 4, 39.99, 159.96),
    (5, 5, 3, 49.99, 149.97);


-- Insertar datos de prueba en la tabla Productos
INSERT INTO Productos (NombreProducto, Descripcion, PrecioUnitario, StockDisponible, Categoria, Proveedor, FechaIngreso)
VALUES
    ('Laptop', 'Laptop de última generación', 1299.99, 50, 'Electrónicos', 1, '2023-01-15'),
    ('Smartphone', 'Teléfono inteligente de gama alta', 799.99, 100, 'Electrónicos', 2, '2023-02-20'),
    ('Mesa de Oficina', 'Mesa ergonómica para oficina', 199.99, 30, 'Muebles', 3, '2023-03-10'),
    ('Impresora', 'Impresora multifunción', 299.99, 20, 'Electrónicos', 1, '2023-04-05'),
    ('Silla de Comedor', 'Silla moderna para comedor', 89.99, 40, 'Muebles', 3, '2023-05-12');

-- Insertar datos de prueba en la tabla Proveedores
INSERT INTO Proveedores (NombreProveedor, Direccion, Ciudad, Estado, CodigoPostal, Telefono, CorreoElectronico)
VALUES
    ('ElectroTech', '123 Tech Street', 'Tech City', 'Tech State', 'T1234', '555-1234', 'info@electrotech.com'),
    ('GadgetWorld', '456 Gadget Lane', 'Gadget Town', 'Gadget State', 'G5678', '555-5678', 'sales@gadgetworld.com'),
    ('FurnitureMasters', '789 Furniture Avenue', 'Furniture City', 'Furniture State', 'F9012', '555-9012', 'contact@furnituremasters.com');
